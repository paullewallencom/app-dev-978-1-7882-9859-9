--SET search_path = apm_watch_management;
INSERT INTO alert_type (
    name,
    created_by,
    updated_by
)
VALUES
    ('ALERT_type1',
    'System',
    'System'),
    ('ALERT_type2',
    'System',
    'System');

