# Chapter 3, IIoT Edge Development
This chapter will help you with the most common tasks in the development of IIoT applications: communication, storing data, and prototyping the devices themselves.
Here you can find an example of IIoT application which runs on Raspberry Pi and sends data to the cloud via various communication protocols.